#include "Includes.h"
#include "zStr.h"

void Gradient(float offsetx, float offsety, float a, float b, ImColor Renk1, ImColor Renk2)
{
	ImDrawList* window = ImGui::GetWindowDrawList();

	ImVec2 panelPos = ImGui::GetWindowPos();

	window->AddRectFilledMultiColor(ImVec2(panelPos.x + offsetx, panelPos.y + offsety), ImVec2(panelPos.x + a, panelPos.y + b), Renk1, Renk1, Renk2, Renk2);

}

void GradientHorizontal(float offsetx, float offsety, float a, float b, ImColor Renk1, ImColor Renk2)
{
	ImDrawList* window = ImGui::GetWindowDrawList();

	ImVec2 panelPos = ImGui::GetWindowPos();

	window->AddRectFilledMultiColor(ImVec2(panelPos.x + offsetx, panelPos.y + offsety), ImVec2(panelPos.x + a, panelPos.y + b), Renk2, Renk1, Renk1, Renk2);

}


void SetupMenuStyle()
{
	ImGuiStyle* s = &ImGui::GetStyle();

	s->WindowMinSize = ImVec2(680, 530);
	s->Alpha = 1.f;
	s->WindowBorderSize = 0.f;
	s->FramePadding = ImVec2(0, 0);
	s->WindowPadding = ImVec2(0, 0);
	s->ItemSpacing = ImVec2(1, 1);
	s->WindowRounding = 10.f;
	s->FrameRounding = 3.f;



	s->Colors[ImGuiCol_WindowBg] = ImColor(22, 21, 22, 255);
	s->Colors[ImGuiCol_Text] = ImColor(255, 255, 255, 255);
	s->Colors[ImGuiCol_Button] = ImColor(30, 30, 30, 0);
	s->Colors[ImGuiCol_ButtonActive] = ImColor(33, 33, 255, 0);
	s->Colors[ImGuiCol_ButtonHovered] = ImColor(33, 33, 255, 0);
	s->Colors[ImGuiCol_FrameBg] = ImColor(30, 30, 30, 255);
	s->Colors[ImGuiCol_FrameBgHovered] = ImColor(33, 33, 33, 255);
	s->Colors[ImGuiCol_FrameBgActive] = ImColor(30, 30, 30, 255);
	s->Colors[ImGuiCol_CheckMark] = ImColor(180, 180, 180, 255);
	s->Colors[ImGuiCol_SliderGrab] = ImColor(50, 50, 50, 255);
	s->Colors[ImGuiCol_SliderGrabActive] = ImColor(60, 60, 60, 255);

	
}

bool testbool1 = false;

void RenderAimbot()
{
	ImGui::SetCursorPosX(250);
	ImGui::SetCursorPosY(250);
}

void RenderAimbotExploits()
{

}
 
void RenderVisualsSelf()
{

}

void RenderVisualsEnemy()
{

}

void RenderVisualsWorld()
{

}

void RenderMiscExploits()
{

}

void RenderMiscColors()
{

}

void RenderMiscConfig()
{

}




void CostumMenu::DrawMenu()
{
	SetupMenuStyle();
	ImGui::Begin("", NULL, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoTitleBar);
	{
		Gradient(0, 62, ImGui::GetWindowWidth(), 65, ImColor(32, 31, 32, 255), ImColor(32, 31, 32, 255));
		Gradient(160, 65, ImGui::GetWindowWidth(), ImGui::GetWindowHeight(), ImColor(25, 24, 25, 255), ImColor(25, 24, 25, 255));

		ImGui::PushFont(CostumFonts::GoodTimes30);
		ImGui::SetCursorPosX(20);
		ImGui::SetCursorPosY(15);
		ImGui::Text(zr("solace"));
		ImGui::PopFont();

		ImGui::PushFont(CostumFonts::Astronomus12);
		ImGui::PushStyleColor(ImGuiCol_Text, (ImVec4)ImColor(180, 180, 180, 255));
		ImGui::SetCursorPosX(20);
		ImGui::SetCursorPosY(100);
		ImGui::Text(zr("combat"));
		ImGui::PopFont();

		ImGui::PushFont(CostumFonts::Astronomus10);
		ImGui::SetCursorPosY(120);
		if (ImGui::Button("##AIMBOT", ImVec2(160, 25)))
		{
			MasterSettings.SettingsTab = 1;
		}
		ImGui::SetCursorPosY(128);
		ImGui::SetCursorPosX(27);
		ImGui::Text("Aimbot");


		ImGui::SetCursorPosY(145);
		if (ImGui::Button("##EXPLOITS", ImVec2(160, 25)))
		{
			MasterSettings.SettingsTab = 2;
		}
		ImGui::SetCursorPosY(153);
		ImGui::SetCursorPosX(27);
		ImGui::Text("Exploits");
		ImGui::PopFont();





		ImGui::PushFont(CostumFonts::Astronomus12);
		ImGui::SetCursorPosX(20);
		ImGui::SetCursorPosY(190);
		ImGui::Text(zr("visuals"));
		ImGui::PopFont();

		ImGui::PushFont(CostumFonts::Astronomus10);
		ImGui::SetCursorPosY(210);
		if (ImGui::Button("##SELF", ImVec2(160, 25)))
		{
			MasterSettings.SettingsTab = 3;
		}
		ImGui::SetCursorPosY(218);
		ImGui::SetCursorPosX(27);
		ImGui::Text("Self");


		ImGui::SetCursorPosY(235);
		if (ImGui::Button("##ENEMY", ImVec2(160, 25)))
		{
			MasterSettings.SettingsTab = 4;
		}
		ImGui::SetCursorPosY(243);
		ImGui::SetCursorPosX(27);
		ImGui::Text("Enemy");



		ImGui::SetCursorPosY(260);
		if (ImGui::Button("##WORLD", ImVec2(160, 25)))
		{
			MasterSettings.SettingsTab = 5;
		}
		ImGui::SetCursorPosY(268);
		ImGui::SetCursorPosX(27);
		ImGui::Text("World");
		ImGui::PopFont();






		ImGui::PushFont(CostumFonts::Astronomus12);
		ImGui::SetCursorPosX(20);
		ImGui::SetCursorPosY(305);
		ImGui::Text(zr("misc"));
		ImGui::PopFont();

		ImGui::PushFont(CostumFonts::Astronomus10);
		ImGui::SetCursorPosY(325);
		if (ImGui::Button("##EXPLOITS2", ImVec2(160, 25)))
		{
			MasterSettings.SettingsTab = 6;
		}
		ImGui::SetCursorPosY(333);
		ImGui::SetCursorPosX(27);
		ImGui::Text("Exploits");



		ImGui::SetCursorPosY(350);
		if (ImGui::Button("##COLORS", ImVec2(160, 25)))
		{
			MasterSettings.SettingsTab = 7;
		}
		ImGui::SetCursorPosY(358);
		ImGui::SetCursorPosX(27);
		ImGui::Text("Colors");

		ImGui::SetCursorPosY(375);
		if (ImGui::Button("##CONFIG", ImVec2(160, 25)))
		{
			MasterSettings.SettingsTab = 8;
		}
		ImGui::SetCursorPosY(383);
		ImGui::SetCursorPosX(27);
		ImGui::Text("Config");

		ImGui::PopFont();



		switch (MasterSettings.SettingsTab)
		{
		case 1:
			GradientHorizontal(0, 120, 4, 145, ImColor(25, 24, 25, 255), ImColor(0, 188, 255, 255));
			RenderAimbot();
			break;
		case 2:
			GradientHorizontal(0, 145, 4, 170, ImColor(25, 24, 25, 255), ImColor(0, 188, 255, 255));
			RenderAimbotExploits();
			break;
		case 3:
			GradientHorizontal(0, 210, 4, 235, ImColor(25, 24, 25, 255), ImColor(0, 188, 255, 255));
			RenderVisualsSelf();
			break;
		case 4:
			GradientHorizontal(0, 235, 4, 260, ImColor(25, 24, 25, 255), ImColor(0, 188, 255, 255));
			RenderVisualsEnemy();
			break;
		case 5:
			GradientHorizontal(0, 260, 4, 285, ImColor(25, 24, 25, 255), ImColor(0, 188, 255, 255));
			RenderVisualsWorld();
			break;
		case 6:
			GradientHorizontal(0, 325, 4, 350, ImColor(25, 24, 25, 255), ImColor(0, 188, 255, 255));
			RenderMiscExploits();
			break;
		case 7:
			GradientHorizontal(0, 350, 4, 375, ImColor(25, 24, 25, 255), ImColor(0, 188, 255, 255));
			RenderMiscColors();
			break;
		case 8:
			GradientHorizontal(0, 375, 4, 400, ImColor(25, 24, 25, 255), ImColor(0, 188, 255, 255));
			RenderMiscConfig();
			break;
		default:

			break;
		}



	}
	ImGui::End();
}