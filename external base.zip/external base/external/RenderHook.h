#include <Windows.h>

extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

namespace DrawingUtils
{
	static HWND MyWnd = NULL;
	static HWND GameWnd = NULL;
	static RECT GameRect = { NULL };
	static int Width = GetSystemMetrics(SM_CXSCREEN);
	static int Height = GetSystemMetrics(SM_CYSCREEN);
	static DWORD ScreenCenterX = NULL;
	static DWORD ScreenCenterY = NULL;
	static IDirect3D9Ex* p_Object = NULL;
	static IDirect3DDevice9* p_Device = NULL;
	static D3DPRESENT_PARAMETERS p_Params = { NULL };
	static MSG Message = { NULL };
}

using namespace DrawingUtils;

LRESULT CALLBACK WinProc(HWND hWnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
	if (ImGui_ImplWin32_WndProcHandler(hWnd, Message, wParam, lParam))
		return true;

	switch (Message)
	{
	case WM_DESTROY:
		PostQuitMessage(0);
		exit(4);
		break;
	case WM_SIZE:
		if (p_Device != NULL && wParam != SIZE_MINIMIZED)
		{
			ImGui_ImplDX9_InvalidateDeviceObjects();
			p_Params.BackBufferWidth = LOWORD(lParam);
			p_Params.BackBufferHeight = HIWORD(lParam);
			HRESULT hr = p_Device->Reset(&p_Params);
			if (hr == D3DERR_INVALIDCALL)
				IM_ASSERT(0);
			ImGui_ImplDX9_CreateDeviceObjects();
		}
		break;
	default:
		return DefWindowProc(hWnd, Message, wParam, lParam);
		break;
	}
	return 0;
}

namespace RenderHook
{
	void SetupWindow();
	HRESULT DirectXInit(HWND hWnd);
	WPARAM MainLoop();
}

