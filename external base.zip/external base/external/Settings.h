#include <Windows.h>

HANDLE ConsoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);

class USettings
{
public:
	// Aim settings
	bool m_Aimbot = true;
	bool m_Prediction = true;
	bool m_Crosshair = true;
	bool m_FOVCircle = true;



	int v_AimbotFOV = 60;
	int v_AimbotSmoothing = 3.0f;
	int v_Distance;

	const char* Hitboxes[2]
	{
		"HEAD",
		"CHEST"
	};




	// Visual settings
	bool m_ESP = false;
	bool m_Skeleton = false;


	int v_ESPDistance;




	// Misc settings
};

class MSettings
{
public:


	bool Show_Menu = true;

	// COMBAT TAB
	// 1 == AIMBOT | 2 == EXPLOITS

	// VISUALS TAB
	// 3 == SELF | 4 == ENEMY | 5 == WORLD

	// MISC TAB
	// 6 == EXPLOITS | 7 == COLORS | 8 == CONFIG
	int SettingsTab = 0;

	
};