
Vector3 Camera(unsigned __int64 RootComponent)
{
	unsigned __int64 PtrPitch;
	Vector3 Camera;

	auto pitch = Driver::read<uintptr_t>(PID, Settings::Majors::LocalPlayer + 0xb0);
	Camera.x = Driver::read<float>(PID, RootComponent + 0x12C);
	Camera.y = Driver::read<float>(PID, pitch + 0x678);

	float test = asin(Camera.y);
	float degrees = test * (180.0 / M_PI);

	Camera.y = degrees;

	if (Camera.x < 0)
		Camera.x = 360 + Camera.x;

	return Camera;
}

void actorLoop() {
	std::vector<ActorStruct> actorStructVector;

	uintptr_t uWorld = Driver::read<uintptr_t>(PID, BaseAddress + 0xC525CD8);
	if (!uWorld) {
		return;
	}
	std::cout << uWorld << std::endl;

	uintptr_t PersistentLevel = Driver::read<uintptr_t>(PID, uWorld + 0x30);
	if (!PersistentLevel) {
		return;
	}

	uintptr_t OwningGameInstance = Driver::read<uintptr_t>(PID, uWorld + 0x190);
	if (!OwningGameInstance) {
		return;
	}

	uintptr_t LocalPlayers = Driver::read<uintptr_t>(PID, OwningGameInstance + 0x38);
	if (!LocalPlayers) {
		return;
	}

	Settings::Majors::LocalPlayer = Driver::read<uintptr_t>(PID, LocalPlayers);
	if (!Settings::Majors::LocalPlayer) {
		return;
	}

	uintptr_t LocalPlayerController = Driver::read<uintptr_t>(PID, Settings::Majors::LocalPlayer + 0x2A8);
	if (!LocalPlayerController) {
		return;
	}

	Settings::Majors::LocalPawn = Driver::read<uintptr_t>(PID, LocalPlayerController + 0x310);
	if (!Settings::Majors::LocalPawn) {
		return;
	}
	else {
		Settings::Majors::LocalPawnRootComponent = Driver::read<uintptr_t>(PID, Settings::Majors::LocalPawn + 0x188);
		Settings::Majors::LocalPlayerRelativeLocation = Driver::read<Vector3>(PID, Settings::Majors::LocalPawnRootComponent + 0x128);

		Settings::Majors::LocalPlayerID = Driver::read<int>(PID, Settings::Majors::LocalPawn + 0x18);
		cout << Settings::Majors::LocalPlayerID << endl;
	}

	uint64_t localplayerstate = Driver::read<uint64_t>(PID, Settings::Majors::LocalPawn + 0x290);
	int LocalTeam = Driver::read<int>(PID, localplayerstate + 0xE88);
	Vector3 Localcam = Camera(Settings::Majors::LocalPawnRootComponent);

	for (int index = 0; index < Driver::read<int>(PID, PersistentLevel + (0x98 + sizeof(uintptr_t))); index++)
	{
		uintptr_t PersistentLevelActors = Driver::read<uintptr_t>(PID, PersistentLevel + 0x98);
		if (!PersistentLevelActors) {
			return;
		}

		uintptr_t CurrentActor = Driver::read<uintptr_t>(PID, PersistentLevelActors + (index * sizeof(uintptr_t)));
		if (!CurrentActor) {
			continue;
		}

		uintptr_t CurrentActorMesh = Driver::read<uintptr_t>(PID, CurrentActor + 0x280);
		if (!CurrentActorMesh) {
			continue;
		}

		int CurrentActorID = Driver::read<int>(PID, CurrentActor + 0x18);
		if (!CurrentActorID) {
			continue;
		}

		bool bSpotted = Driver::read<bool>(PID, CurrentActor + 0x682);
		if (bSpotted == false) {
			continue;
		}

		if (CurrentActorID != 0 && ((CurrentActorID == Settings::Majors::LocalPlayerID) || (bSpotted != 0 && Settings::Majors::CorrectbSpotted == bSpotted))) {
			Settings::Majors::CorrectbSpotted = bSpotted;

			ActorStruct Actor{ };
			Actor.pObjPointer = CurrentActor;
			Actor.ID = CurrentActorID;
			Actor.Mesh = CurrentActorMesh;

			actorStructVector.push_back(Actor);
		}
		for (const ActorStruct& ActorStruct : actorStructVector)
		{
			if (ActorStruct.pObjPointer == Settings::Majors::LocalPawn) {
				continue;
			}
			uint64_t playerstate = Driver::read<uint64_t>(PID, ActorStruct.pObjPointer + 0x240);
			int TeamIndex = Driver::read<int>(PID, playerstate + 0xF28);
		}
	}

	if (actorStructVector.empty()) {
		return;
	}

	bool bValidEnemyInArea = false;
	float ClosestActorDistance = FLT_MAX;
	Vector3 ClosestActorMouseAimbotPosition = Vector3(0.0f, 0.0f, 0.0f);
	float distance;

	for (const ActorStruct& ActorStruct : actorStructVector)
	{
		if (ActorStruct.pObjPointer == Settings::Majors::LocalPawn) {
			continue;
		}

		uintptr_t RootComponent = Driver::read<uintptr_t>(PID, ActorStruct.pObjPointer + 0x130);
		if (!RootComponent) {
			continue;
		}

		uint64_t playerstate = Driver::read<uint64_t>(PID, ActorStruct.pObjPointer + 0x240);
		int TeamIndex = Driver::read<int>(PID, playerstate + 0xE88);

		Vector3 vHeadBone = GetBoneWithRotation(ActorStruct.Mesh, 66);
		Vector3 vRootBone = GetBoneWithRotation(ActorStruct.Mesh, 0);

		Vector3 vHeadBoneOut = ProjectWorldToScreen(Vector3(vHeadBone.x, vHeadBone.y, vHeadBone.z + 20), Vector3(Localcam.y, Localcam.x, Localcam.z));
		Vector3 vRootBoneOut = ProjectWorldToScreen(vRootBone, Vector3(Localcam.y, Localcam.x, Localcam.z));

		Vector3 RootPos = GetBoneWithRotation(ActorStruct.Mesh, select_hitbox());
		Vector3 selection;

		float BoxHeight = vHeadBoneOut.y - vRootBoneOut.y;

		if (BoxHeight < 0)
			BoxHeight = BoxHeight * (-1.f);
		float BoxWidth = BoxHeight * 0.35;


		Vector3 RelativeInternalLocation = Driver::read<Vector3>(PID, RootComponent + 0x11C);
		if (!RelativeInternalLocation.x && !RelativeInternalLocation.y) {
			continue;
		}

		Vector3 RelativeScreenLocation = ProjectWorldToScreen(RelativeInternalLocation, Vector3(Localcam.y, Localcam.x, Localcam.z));
		if (!RelativeScreenLocation.x && !RelativeScreenLocation.y) {
			continue;
		}

		distance = Settings::Majors::LocalPlayerRelativeLocation.Distance(RelativeInternalLocation) / 100.f;

		if (TeamIndex != LocalTeam) {

			if (distance <= UserSettings.v_ESPDistance) {

				if (UserSettings.m_Prediction) {

					Vector3 Velocity = Driver::read<Vector3>(PID, ActorStruct.pObjPointer + 0x140);
					auto Result = CalculatePrediction(RootPos, Velocity, distance, 275.0f);
					selection = ProjectWorldToScreen(Result, Vector3(Localcam.y, Localcam.x, Localcam.z));
				}

				float ScreenLocationX = selection.x - Settings::Majors::ScreenCenterX, ScreenLocationY = selection.y - Settings::Majors::ScreenCenterY;
				float ActorDistance = std::sqrtf(ScreenLocationX * ScreenLocationX + ScreenLocationY * ScreenLocationY);

				if (UserSettings.m_ESP)
				{
					DrawCornerBox(vRootBoneOut.x - (BoxWidth / 2), vHeadBoneOut.y, BoxWidth, BoxHeight, 1.9f, &ESPColor);
				}

				if (ActorDistance < ClosestActorDistance && ActorDistance < UserSettings.v_AimbotFOV) {
					ClosestActorDistance = ActorDistance;
					ClosestActorMouseAimbotPosition = Vector3(ScreenLocationX, ScreenLocationY, 0.0f);
					bValidEnemyInArea = true;
				}
			}
		}
	}

	if (UserSettings.m_Aimbot && bValidEnemyInArea && GetAsyncKeyState(hotkeys::aimkey)) {
		float PlayerLocationX = ClosestActorMouseAimbotPosition.x /= UserSettings.v_AimbotSmoothing, PlayerLocationY = ClosestActorMouseAimbotPosition.y /= UserSettings.v_AimbotSmoothing;

		if (!PlayerLocationX || !PlayerLocationY) {
			return;
		}

		mouse_event(MOUSEEVENTF_MOVE, PlayerLocationX, PlayerLocationY, 0, 0);
	}
}