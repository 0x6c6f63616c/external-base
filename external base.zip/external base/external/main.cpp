#include "Includes.h"
#include "zStr.h"


int main()
{
	SetConsoleTitle(L"");
	
	SetConsoleTextAttribute(ConsoleHandle, 3);

	RenderHook::SetupWindow();
	RenderHook::DirectXInit(MyWnd);
	RenderHook::MainLoop();

	Sleep(-1);
}