#include <Windows.h>
#include "ImGui/imgui.h"

namespace CostumFonts
{
	inline ImFont* SunAndMoon80;
	inline ImFont* SunAndMoon40;
	inline ImFont* SunAndMoon20;
	inline ImFont* SunAndMoon18;
	inline ImFont* SunAndMoon16;
	inline ImFont* SunAndMoon14;
	inline ImFont* SunAndMoon12;
	inline ImFont* SunAndMoon10;

	inline ImFont* GoodTimes80;
	inline ImFont* GoodTimes40;
	inline ImFont* GoodTimes30;
	inline ImFont* GoodTimes20;
	inline ImFont* GoodTimes18;
	inline ImFont* GoodTimes16;
	inline ImFont* GoodTimes14;
	inline ImFont* GoodTimes12;
	inline ImFont* GoodTimes10;




	inline ImFont* Astronomus20;
	inline ImFont* Astronomus18;
	inline ImFont* Astronomus16;
	inline ImFont* Astronomus14;
	inline ImFont* Astronomus12;
	inline ImFont* Astronomus10;
}


class CostumMenu
{
public:
	void DrawMenu();
};