// Windows predefined imports
#include <windows.h>
#include <iostream>
#include <string>
#include <vector>
#include <math.h>
#include <TlHelp32.h>
#include <Psapi.h>
#include <tchar.h>
#include <winioctl.h>
#include <d3d9.h>
#include "d3dx9.h"
#include <dwmapi.h>
#include <iostream>
#include <tlhelp32.h>
#include <fstream>
#include <filesystem>
#include <iostream>
#include <vector>
#include <iomanip>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <cstdio>
#include <string>
#include<iostream> 
#include<fstream>
#include <Windows.h>
#include <stdio.h>

// ImGui
#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_win32.h"
#include "ImGui/imgui_internal.h"
#include "ImGui/imgui_impl_dx9.h"

// Fonts
#include "SunAndMoon.h"
#include "GoodTimes.h"
#include "Astronomus.h"


// Offsets
uintptr_t BaseAddress;
uintptr_t PID;

// Namespaces & Libs
using namespace std;

#pragma comment(lib, "urlmon.lib")
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")
#pragma comment(lib, "dwmapi.lib")

// Driver

#include "Protect.h"


// Settings / Config
#include "Settings.h"
USettings UserSettings;
MSettings MasterSettings;

// Classes
#include "RenderHook.h"
#include "Menu.h"

CostumMenu CMenu;