#include "Includes.h"

void RenderHook::SetupWindow()
{
	GameWnd = FindWindowW(NULL, TEXT("New Tab - Brave"));

	if (GameWnd)
	{
		GetClientRect(GameWnd, &GameRect);

		POINT xy = { 0 };

		ClientToScreen(GameWnd, &xy);

		GameRect.left = xy.x;
		GameRect.top = xy.y;

		Width = GameRect.right;
		Height = GameRect.bottom;
	}
	else {
		exit(2);
	}

	WNDCLASSEX overlayWindowClass;
	ZeroMemory(&overlayWindowClass, sizeof(WNDCLASSEX));
	overlayWindowClass.cbClsExtra = NULL;
	overlayWindowClass.cbWndExtra = NULL;
	overlayWindowClass.cbSize = sizeof(WNDCLASSEX);
	overlayWindowClass.style = CS_HREDRAW | CS_VREDRAW;
	overlayWindowClass.lpfnWndProc = WinProc;
	overlayWindowClass.hInstance = NULL;
	overlayWindowClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	overlayWindowClass.hIcon = LoadIcon(0, IDI_APPLICATION);
	overlayWindowClass.hIconSm = LoadIcon(0, IDI_APPLICATION);
	overlayWindowClass.hbrBackground = (HBRUSH)RGB(0, 0, 0);
	overlayWindowClass.lpszClassName = L"solace";
	overlayWindowClass.lpszMenuName = L"solace";
	RegisterClassEx(&overlayWindowClass);

	MyWnd = CreateWindowEx(NULL, L"solace", L"solace", WS_POPUP | WS_VISIBLE, GameRect.left, GameRect.top, Width, Height, NULL, NULL, NULL, NULL);

	MARGINS margin = { GameRect.left, GameRect.top, Width, Height };
	DwmExtendFrameIntoClientArea(MyWnd, &margin);

	SetWindowLong(MyWnd, GWL_EXSTYLE, WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW);

	ShowWindow(MyWnd, SW_SHOW);
	UpdateWindow(MyWnd);
}

HRESULT RenderHook::DirectXInit(HWND hwnd)
{
	if (FAILED(Direct3DCreate9Ex(D3D_SDK_VERSION, &p_Object)))
		exit(3);

	ImFontConfig font_config;
	font_config.OversampleH = 1;
	font_config.OversampleV = 1;
	font_config.PixelSnapH = true;

	static const ImWchar ranges[] =
	{
		0x0020, 0x00FF,
		0x0400, 0x044F,
		0,
	};

	ZeroMemory(&p_Params, sizeof(p_Params));
	p_Params.BackBufferWidth = Width;
	p_Params.BackBufferHeight = Height;
	p_Params.BackBufferFormat = D3DFMT_A8R8G8B8;
	p_Params.MultiSampleQuality = D3DMULTISAMPLE_NONE;
	p_Params.AutoDepthStencilFormat = D3DFMT_D16;
	p_Params.SwapEffect = D3DSWAPEFFECT_DISCARD;
	p_Params.EnableAutoDepthStencil = TRUE;
	p_Params.hDeviceWindow = MyWnd;
	p_Params.Windowed = TRUE;

	p_Object->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, MyWnd, D3DCREATE_SOFTWARE_VERTEXPROCESSING, &p_Params, &p_Device);

	IMGUI_CHECKVERSION();

	ImGui::CreateContext();
	ImGuiIO& io = ImGui::GetIO();
	(void)io;

	io.IniFilename = nullptr; //crutial for not leaving the imgui.ini file

	ImGui_ImplWin32_Init(MyWnd);
	ImGui_ImplDX9_Init(p_Device);

	io.Fonts->AddFontDefault();

	// ADD COSTUM FONTS HERE
	CostumFonts::SunAndMoon80 = io.Fonts->AddFontFromMemoryTTF((void*)SunAndMoonFont, sizeof(SunAndMoonFont), 80.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());
	CostumFonts::SunAndMoon40 = io.Fonts->AddFontFromMemoryTTF((void*)SunAndMoonFont, sizeof(SunAndMoonFont), 40.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());
	CostumFonts::SunAndMoon20 = io.Fonts->AddFontFromMemoryTTF((void*)SunAndMoonFont, sizeof(SunAndMoonFont), 20.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());
	CostumFonts::SunAndMoon18 = io.Fonts->AddFontFromMemoryTTF((void*)SunAndMoonFont, sizeof(SunAndMoonFont), 18.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());
	CostumFonts::SunAndMoon16 = io.Fonts->AddFontFromMemoryTTF((void*)SunAndMoonFont, sizeof(SunAndMoonFont), 16.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());
	CostumFonts::SunAndMoon14 = io.Fonts->AddFontFromMemoryTTF((void*)SunAndMoonFont, sizeof(SunAndMoonFont), 14.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());
	CostumFonts::SunAndMoon12 = io.Fonts->AddFontFromMemoryTTF((void*)SunAndMoonFont, sizeof(SunAndMoonFont), 12.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());
	CostumFonts::SunAndMoon10 = io.Fonts->AddFontFromMemoryTTF((void*)SunAndMoonFont, sizeof(SunAndMoonFont), 10.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());


	CostumFonts::GoodTimes80 = io.Fonts->AddFontFromMemoryTTF((void*)GoodTimes, sizeof(GoodTimes), 80.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());
	CostumFonts::GoodTimes40 = io.Fonts->AddFontFromMemoryTTF((void*)GoodTimes, sizeof(GoodTimes), 40.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());
	CostumFonts::GoodTimes30 = io.Fonts->AddFontFromMemoryTTF((void*)GoodTimes, sizeof(GoodTimes), 30.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());
	CostumFonts::GoodTimes20 = io.Fonts->AddFontFromMemoryTTF((void*)GoodTimes, sizeof(GoodTimes), 20.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());
	CostumFonts::GoodTimes18 = io.Fonts->AddFontFromMemoryTTF((void*)GoodTimes, sizeof(GoodTimes), 18.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());
	CostumFonts::GoodTimes16 = io.Fonts->AddFontFromMemoryTTF((void*)GoodTimes, sizeof(GoodTimes), 16.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());
	CostumFonts::GoodTimes14 = io.Fonts->AddFontFromMemoryTTF((void*)GoodTimes, sizeof(GoodTimes), 14.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());
	CostumFonts::GoodTimes12 = io.Fonts->AddFontFromMemoryTTF((void*)GoodTimes, sizeof(GoodTimes), 12.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());
	CostumFonts::GoodTimes10 = io.Fonts->AddFontFromMemoryTTF((void*)GoodTimes, sizeof(GoodTimes), 10.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());






	CostumFonts::Astronomus20 = io.Fonts->AddFontFromMemoryTTF((void*)Astronomus, sizeof(Astronomus), 20.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());
	CostumFonts::Astronomus18 = io.Fonts->AddFontFromMemoryTTF((void*)Astronomus, sizeof(Astronomus), 18.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());
	CostumFonts::Astronomus16 = io.Fonts->AddFontFromMemoryTTF((void*)Astronomus, sizeof(Astronomus), 16.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());
	CostumFonts::Astronomus14 = io.Fonts->AddFontFromMemoryTTF((void*)Astronomus, sizeof(Astronomus), 14.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());
	CostumFonts::Astronomus12 = io.Fonts->AddFontFromMemoryTTF((void*)Astronomus, sizeof(Astronomus), 12.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());
	CostumFonts::Astronomus10 = io.Fonts->AddFontFromMemoryTTF((void*)Astronomus, sizeof(Astronomus), 10.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());

}

void ChangeClickability(bool canclick, HWND ownd)
{
	long style = GetWindowLong(ownd, GWL_EXSTYLE);
	if (canclick) {
		style &= ~WS_EX_LAYERED;
		SetWindowLong(ownd, GWL_EXSTYLE, style);
		SetForegroundWindow(ownd);
		//windowstate = 1;
	}
	else {
		style |= WS_EX_LAYERED;
		SetWindowLong(ownd, GWL_EXSTYLE, style);
		//windowstate = 0;
	}
}

void render() {

	ImGui_ImplDX9_NewFrame();
	ImGui_ImplWin32_NewFrame();
	ImGui::NewFrame();

	if (GetAsyncKeyState(VK_F2) & 1)
	{
		MasterSettings.Show_Menu = !MasterSettings.Show_Menu;
	}

	if (MasterSettings.Show_Menu)
	{
		CMenu.DrawMenu();
		ChangeClickability(true, MyWnd);

	}
	else
	{
		ChangeClickability(false, MyWnd);
	}

	//ImGui::GetBackgroundDrawList()->AddCircle(ImVec2(ScreenCenterX, ScreenCenterY), 150.f, ImGui::GetColorU32({ 199.f, 45.f, 27.f, 4.0f }) , 100, 2.f);

	ImGui::EndFrame();
	p_Device->SetRenderState(D3DRS_ZENABLE, false);
	p_Device->SetRenderState(D3DRS_ALPHABLENDENABLE, false);
	p_Device->SetRenderState(D3DRS_SCISSORTESTENABLE, false);
	p_Device->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_ARGB(0, 0, 0, 0), 1.0f, 0);
	if (p_Device->BeginScene() >= 0)
	{
		ImGui::Render();
		ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());
		p_Device->EndScene();
	}
	HRESULT result = p_Device->Present(NULL, NULL, NULL, NULL);

	if (result == D3DERR_DEVICELOST && p_Device->TestCooperativeLevel() == D3DERR_DEVICENOTRESET)
	{
		ImGui_ImplDX9_InvalidateDeviceObjects();
		p_Device->Reset(&p_Params);
		ImGui_ImplDX9_CreateDeviceObjects();
	}
}

WPARAM RenderHook::MainLoop()
{
	static RECT old_rc;
	ZeroMemory(&Message, sizeof(MSG));

	while (Message.message != WM_QUIT)
	{
		if (PeekMessage(&Message, MyWnd, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&Message);
			DispatchMessage(&Message);
		}

		HWND hwnd_active = GetForegroundWindow();

		if (hwnd_active == GameWnd) {
			HWND hwndtest = GetWindow(hwnd_active, GW_HWNDPREV);
			SetWindowPos(MyWnd, hwndtest, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		}

		if (GetAsyncKeyState(0x23) & 1)
			exit(8);

		RECT rc;
		POINT xy;

		ZeroMemory(&rc, sizeof(RECT));
		ZeroMemory(&xy, sizeof(POINT));
		GetClientRect(MyWnd, &rc);
		ClientToScreen(MyWnd, &xy);
		rc.left = xy.x;
		rc.top = xy.y;

		ImGuiIO& io = ImGui::GetIO();
		io.DeltaTime = 1.0f / 60.0f;

		POINT p;
		GetCursorPos(&p);
		io.MousePos.x = p.x - xy.x;
		io.MousePos.y = p.y - xy.y;

		if (GetAsyncKeyState(VK_LBUTTON)) {
			io.MouseDown[0] = true;
			io.MouseClicked[0] = true;
			io.MouseClickedPos[0].x = io.MousePos.x;
			io.MouseClickedPos[0].x = io.MousePos.y;
		}
		else
			io.MouseDown[0] = false;

		if (rc.left != old_rc.left || rc.right != old_rc.right || rc.top != old_rc.top || rc.bottom != old_rc.bottom)
		{
			old_rc = rc;

			Width = rc.right;
			Height = rc.bottom;

			p_Params.BackBufferWidth = Width;
			p_Params.BackBufferHeight = Height;
			SetWindowPos(GameWnd, (HWND)0, xy.x, xy.y, Width, Height, SWP_NOREDRAW);
			p_Device->Reset(&p_Params);
		}
		//actorLoop();
		render();
	}
	ImGui_ImplDX9_Shutdown();
	ImGui_ImplWin32_Shutdown();
	ImGui::DestroyContext();

	DestroyWindow(GameWnd);
}